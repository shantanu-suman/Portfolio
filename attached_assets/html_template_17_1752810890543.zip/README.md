# Modern Portfolio Website

A clean, responsive, and professional portfolio website template built with HTML, CSS, and JavaScript.

## Features

- Responsive design that works on all devices
- Modern and clean UI with smooth animations
- Multi-page structure with home, projects, and contact pages
- Project filtering functionality
- Contact form with validation
- Social media integration
- Interactive elements and hover effects

## Pages

1. **Home Page** - Introduction, about section, skills, and featured projects
2. **Projects Page** - Gallery of projects with filtering by category
3. **Contact Page** - Contact form and information

## Technologies Used

- HTML5
- CSS3 (with flexbox and grid layouts)
- JavaScript (vanilla JS, no frameworks)
- Font Awesome icons
- Google Fonts

## File Structure

```
portfolio-website/
├── index.html             # Home page
├── projects.html          # Projects page
├── contact.html           # Contact page
├── css/
│   ├── style.css          # Main styles (shared across all pages)
│   ├── home.css           # Home page specific styles
│   ├── projects.css       # Projects page specific styles
│   ├── contact.css        # Contact page specific styles
│   └── animations.css     # Animation utilities
├── js/
│   ├── script.js          # Main JavaScript (shared across all pages)
│   ├── home.js            # Home page specific scripts
│   ├── projects.js        # Projects page specific scripts
│   └── contact.js         # Contact page specific scripts
└── README.md              # Project documentation
```

## How to Use

1. Clone or download this repository
2. Open `index.html` in your browser to view the website
3. Customize the content, colors, and styles to fit your personal brand
4. Replace placeholder images with your own

## Customization

### Colors

You can easily customize the color scheme by modifying the CSS variables in the `:root` section of the `style.css` file:

```css
:root {
    --primary-color: #4a6cf7;
    --secondary-color: #101c36;
    --text-color: #5d6a85;
    --dark-gray: #6c7a93;
    --medium-gray: #dce1e9;
    --light-gray: #f3f4f8;
    --white: #ffffff;
    --shadow-color: rgba(10, 22, 31, 0.05);
    --transition-speed: 0.3s;
    --border-radius: 10px;
}
```

### Content

Update the text content in each HTML file to reflect your personal information, projects, and contact details.

### Projects

To add a new project:

1. Copy the project card HTML structure in `projects.html`
2. Update the project image, title, description, and links
3. Set the appropriate data-category attribute for filtering

## License

This template is available for personal and commercial use.

## Credits

- Placeholder images via [Placeholder.com](https://placeholder.com/)
- Icons by [Font Awesome](https://fontawesome.com/)
- Fonts from [Google Fonts](https://fonts.google.com/)