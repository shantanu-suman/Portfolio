document.addEventListener('DOMContentLoaded', function() {
    console.log('Portfolio website loaded!');
    
    // Mobile Navigation Toggle
    const menuToggle = document.getElementById('menu-toggle');
    const navbar = document.getElementById('navbar');
    
    if(menuToggle) {
        menuToggle.addEventListener('click', function() {
            const navList = navbar.querySelector('ul');
            navList.classList.toggle('active');
            
            // Animation for hamburger to X
            const spans = menuToggle.querySelectorAll('span');
            spans.forEach(span => span.classList.toggle('active'));
            
            if(navList.classList.contains('active')) {
                spans[0].style.transform = 'rotate(45deg) translate(5px, 5px)';
                spans[1].style.opacity = '0';
                spans[2].style.transform = 'rotate(-45deg) translate(7px, -8px)';
            } else {
                spans[0].style.transform = 'none';
                spans[1].style.opacity = '1';
                spans[2].style.transform = 'none';
            }
        });
    }
    
    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href').substring(1);
            if (!targetId) return;
            
            const targetElement = document.getElementById(targetId);
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 80,
                    behavior: 'smooth'
                });
                
                // Update URL without refreshing the page
                history.pushState(null, null, `#${targetId}`);
            }
        });
    });
    
    // Add active class to current page in navbar
    function setActiveNavItem() {
        const currentPage = window.location.pathname.split("/").pop();
        const navLinks = document.querySelectorAll('nav ul li a');
        
        navLinks.forEach(link => {
            const linkHref = link.getAttribute('href');
            if (linkHref === currentPage || (currentPage === '' && linkHref === 'index.html')) {
                link.classList.add('active');
            } else {
                link.classList.remove('active');
            }
        });
    }
    
    setActiveNavItem();
    
    // Animate elements when they come into view
    const animateOnScroll = function() {
        const elements = document.querySelectorAll('.animate-on-scroll');
        
        elements.forEach(element => {
            const elementPosition = element.getBoundingClientRect().top;
            const windowHeight = window.innerHeight;
            
            if (elementPosition < windowHeight - 50) {
                element.classList.add('in-view');
            }
        });
    };
    
    // Add the animate-on-scroll class to elements that should be animated
    function setupScrollAnimations() {
        const sectionsToAnimate = document.querySelectorAll('section:not(.hero)');
        sectionsToAnimate.forEach(section => {
            section.classList.add('animate-on-scroll');
        });
        
        // Initially check if elements are in view
        animateOnScroll();
        
        // Add scroll event listener
        window.addEventListener('scroll', animateOnScroll);
    }
    
    setupScrollAnimations();
});