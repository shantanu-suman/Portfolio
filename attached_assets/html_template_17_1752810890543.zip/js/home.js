document.addEventListener('DOMContentLoaded', function() {
    console.log('Home page loaded!');
    
    // Handle animation delays for stats counter
    const stats = document.querySelectorAll('.stat-number');
    
    // Only run animation if stats are present (home page)
    if(stats.length > 0) {
        // Animate stats counter when in view
        const animateStats = function() {
            const statsSection = document.querySelector('.stats');
            if (!statsSection) return;
            
            const statsSectionPosition = statsSection.getBoundingClientRect().top;
            const windowHeight = window.innerHeight;
            
            if (statsSectionPosition < windowHeight - 100) {
                stats.forEach(stat => {
                    const targetValue = parseInt(stat.textContent);
                    if (stat.dataset.counted) return;
                    
                    stat.dataset.counted = true;
                    let currentValue = 0;
                    const increment = targetValue / 50; // Divide by the number of steps
                    const duration = 1500; // Total duration in ms
                    const stepTime = duration / 50; // Time per step
                    
                    const counter = setInterval(function() {
                        currentValue += increment;
                        if (currentValue >= targetValue) {
                            stat.textContent = targetValue + (stat.textContent.includes('%') ? '%' : '');
                            clearInterval(counter);
                        } else {
                            stat.textContent = Math.floor(currentValue) + (stat.textContent.includes('%') ? '%' : '');
                        }
                    }, stepTime);
                });
                
                // Remove scroll listener once animation is triggered
                window.removeEventListener('scroll', animateStats);
            }
        };
        
        // Check on scroll and on initial load
        window.addEventListener('scroll', animateStats);
        animateStats(); // Check on initial load
    }
    
    // Add hover effects to project cards
    const projectCards = document.querySelectorAll('.project-card');
    
    projectCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.querySelector('.project-overlay').style.opacity = '1';
        });
        
        card.addEventListener('mouseleave', function() {
            this.querySelector('.project-overlay').style.opacity = '0';
        });
    });
});